/* Dummy sfp-machine.h header for targets that don't need one.  */
