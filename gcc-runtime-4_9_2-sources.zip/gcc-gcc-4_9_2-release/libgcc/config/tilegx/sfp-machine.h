#ifdef __tilegx32__
#include "config/tilegx/sfp-machine32.h"
#else
#include "config/tilegx/sfp-machine64.h"
#endif
