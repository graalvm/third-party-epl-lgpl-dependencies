#ifndef __RX_64BIT_DOUBLES__
#define DF SF
#define FLOAT_ONLY
#endif

