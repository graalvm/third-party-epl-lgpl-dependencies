#ifdef FLOAT
#ifdef __H8300__
#define CMPtype HItype
#else
#define CMPtype SItype
#endif
#endif
