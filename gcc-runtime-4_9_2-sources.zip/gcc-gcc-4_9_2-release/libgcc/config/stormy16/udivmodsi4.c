#define XSTORMY16_UDIVMODSI4
#include "lib2funcs.c"
