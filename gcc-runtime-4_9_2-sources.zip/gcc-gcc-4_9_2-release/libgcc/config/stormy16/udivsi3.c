#define XSTORMY16_UDIVSI3
#include "lib2funcs.c"
