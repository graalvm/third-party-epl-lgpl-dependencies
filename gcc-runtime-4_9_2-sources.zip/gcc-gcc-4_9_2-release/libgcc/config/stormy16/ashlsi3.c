#define XSTORMY16_ASHLSI3
#include "lib2funcs.c"
