#define XSTORMY16_CMPSI2
#include "lib2funcs.c"
