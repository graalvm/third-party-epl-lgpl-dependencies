#define XSTORMY16_UMODSI3
#include "lib2funcs.c"
