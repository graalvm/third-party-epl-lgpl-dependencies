#define XSTORMY16_DIVSI3
#include "lib2funcs.c"
