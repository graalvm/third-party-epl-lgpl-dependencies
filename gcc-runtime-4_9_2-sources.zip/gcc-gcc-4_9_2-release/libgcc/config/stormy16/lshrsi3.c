#define XSTORMY16_LSHRSI3
#include "lib2funcs.c"
