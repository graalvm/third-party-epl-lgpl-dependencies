#define XSTORMY16_CLZHI2
#include "lib2funcs.c"
