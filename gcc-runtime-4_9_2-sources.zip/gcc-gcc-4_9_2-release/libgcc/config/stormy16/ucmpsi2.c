#define XSTORMY16_UCMPSI2
#include "lib2funcs.c"
