#define XSTORMY16_FFSHI2
#include "lib2funcs.c"
