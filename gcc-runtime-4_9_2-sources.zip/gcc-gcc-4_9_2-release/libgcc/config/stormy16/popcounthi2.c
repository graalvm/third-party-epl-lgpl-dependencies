#define XSTORMY16_POPCOUNTHI2
#include "lib2funcs.c"
