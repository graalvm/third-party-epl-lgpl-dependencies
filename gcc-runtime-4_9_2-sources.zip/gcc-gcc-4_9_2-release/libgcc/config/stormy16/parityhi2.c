#define XSTORMY16_PARITYHI2
#include "lib2funcs.c"
