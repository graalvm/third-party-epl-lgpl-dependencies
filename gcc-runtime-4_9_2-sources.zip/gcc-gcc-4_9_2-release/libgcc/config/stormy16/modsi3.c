#define XSTORMY16_MODSI3
#include "lib2funcs.c"
