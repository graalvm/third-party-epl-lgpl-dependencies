#define XSTORMY16_ASHRSI3
#include "lib2funcs.c"
