#define XSTORMY16_CTZHI2
#include "lib2funcs.c"
