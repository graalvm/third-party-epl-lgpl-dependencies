#define XSTORMY16_CLRSBHI2
#include "lib2funcs.c"
