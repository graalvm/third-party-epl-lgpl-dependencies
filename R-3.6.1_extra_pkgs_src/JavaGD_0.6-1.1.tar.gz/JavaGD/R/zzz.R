.onLoad <- function(libname, pkgname)
  .javaGD.set.class.path(system.file("java", "javaGD.jar", package="JavaGD"))

